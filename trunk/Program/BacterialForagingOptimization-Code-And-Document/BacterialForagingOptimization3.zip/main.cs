using System;

// Demonstration of an algorithm based on the behavior of E. coli bacteria to solve
// a difficult minimization problem called the Rastrigin function.

namespace BacterialForagingOptimization
{
  class BacterialForagingOptimizationProgram
  {
    static Random random = null;

    static void Main(string[] args)
    {
      try
      {
        Console.WriteLine("\nBegin Bacterial Foraging Optimization demo\n");
        Console.WriteLine("Target function to minimize: f(x,y) = (x^2 - 10*cos(2*PI*x)) + (y^2 - 10*cos(2*PI*y)) + 20");
        Console.WriteLine("Target function has known optimum value = 0.0 at x = 0.0 and y = 0.0");
        
        int dim = 2; // problem dimension ("p")
        double minValue = -5.12;
        double maxValue = 5.12;
        int S = 100; // colony size; evenly divisible by 2
        int Nc = 20; // chemotactic steps, index = j
        int Ns = 5; // maximum swim steps, index = m
        int Nre = 8; // reproduction steps, index = k
        int Ned = 4; // dispersal steps, index = l ('el')
        double Ped = 0.25; // probability of dispersal
        double Ci = 0.05; // basic bacteria movement increment size (for all bacteria)

        Console.WriteLine("\nColony size = " + S);
        Console.WriteLine("Chemotactic step count = " + Nc);
        Console.WriteLine("Reproduction step count = " + Nre);
        Console.WriteLine("Dispersal step count = " + Ned);
        Console.WriteLine("Maximum swim step count = " + Ns);
        Console.WriteLine("Death probability = " + Ped.ToString("F2"));
        Console.WriteLine("Base swim length = " + Ci.ToString("F2"));

        random = new Random(0);

        // initialize bacteria colony
        Console.WriteLine("\nInitializing bacteria colony to random positions");
        Colony colony = new Colony(S, dim, minValue, maxValue); // initialize a colony of bacteria at random positions (but not the costs)
        Console.WriteLine("Computing the cost value for each bacterium");
        for (int i = 0; i < S; ++i) // costs
        {
          double cost = Cost(colony.bacteria[i].position); // compute cost
          colony.bacteria[i].cost = cost;
          colony.bacteria[i].prevCost = cost;
           
        }

        // find best initial cost and position (could have done this with the init loop)
        double bestCost = colony.bacteria[0].cost;
        int indexOfBest = 0;
        for (int i = 0; i < S; ++i) { if (colony.bacteria[i].cost < bestCost) { bestCost = colony.bacteria[i].cost; indexOfBest = i; } }
        double[] bestPosition = new double[dim];
        colony.bacteria[indexOfBest].position.CopyTo(bestPosition, 0);
         Console.WriteLine("\nIndex of bacterial = " + colony.bacteria[indexOfBest].position);

        //Console.WriteLine(colony.ToString());
        Console.WriteLine("\nBest initial cost = " + bestCost.ToString("F4"));

        // main processing
        Console.WriteLine("\nEntering main BFO tumble-swim-reproduce-disperse algorithm loop\n");
        int t = 0;                    // time counter
        for (int l = 0; l < Ned; ++l) // eliminate-disperse loop
        {
          for (int k = 0; k < Nre; ++k) // reproduce-eliminate loop
          {
            for (int j = 0; j < Nc; ++j) // chemotactic loop; the lifespan of each bacterium
            {
              // reset the health of each bacterium to 0.0 
              for (int i = 0; i < S; ++i) { colony.bacteria[i].health = 0.0; }

              for (int i = 0; i < S; ++i) // each bacterium
              {
                double[] tumble = new double[dim]; // tumble (point in a new direction)
                for (int p = 0; p < dim; ++p) { tumble[p] = 2.0 * random.NextDouble() - 1.0;  Console.WriteLine("\nTumble values= " +tumble[p]); } // (hi - lo) * r + lo => random i [-1, +1]
                double rootProduct = 0.0;
                for (int p = 0; p < dim; ++p) { rootProduct += (tumble[p] * tumble[p]); Console.WriteLine("\nTumble values= " + rootProduct);}
                
                for (int p = 0; p < dim; ++p) { colony.bacteria[i].position[p] += (Ci * tumble[p]) / rootProduct;Console.WriteLine("\nTumble values= " + colony.bacteria[i].position[p]);} // move in new direction
                
                // update costs of new position
                colony.bacteria[i].prevCost = colony.bacteria[i].cost;
                colony.bacteria[i].cost = Cost(colony.bacteria[i].position);
                colony.bacteria[i].health += colony.bacteria[i].cost; // health is an accumulation of costs during bacterium's life

                // new best?
                if (colony.bacteria[i].cost < bestCost)
                {
                  Console.WriteLine("New best solution found by bacteria1 " + i.ToString().PadLeft(2) + " at time = " + t);
                  bestCost = colony.bacteria[i].cost;
                  colony.bacteria[i].position.CopyTo(bestPosition, 0);
                  Console.WriteLine("\nupdates cost  of new position1= " +bestCost);  
                }

                int m = 0; // swim or not based on prev and curr costs
                while (m < Ns && colony.bacteria[i].cost < colony.bacteria[i].prevCost) // we are improving
                {
                  ++m; // swim counter
                  for (int p = 0; p < dim; ++p) { colony.bacteria[i].position[p] += (Ci * tumble[p]) / rootProduct; } // move in current direction
                  colony.bacteria[i].prevCost = colony.bacteria[i].cost; // update costs
                  colony.bacteria[i].cost = Cost(colony.bacteria[i].position);
                  if (colony.bacteria[i].cost < bestCost) // did we find a new best?
                  {
                    Console.WriteLine("New best solution found by bacteria2 " + i.ToString().PadLeft(2) + " at time = " + t);
                    bestCost = colony.bacteria[i].cost;
                    colony.bacteria[i].position.CopyTo(bestPosition, 0);
                    Console.WriteLine("\nupdates cost  of new position2= " +bestCost);
                  }
                } // while improving
               
              } // i, each bacterium in the chemotactic loop

              ++t;   // increment the time counter
  
            } // j, chemotactic loop

            // reproduce the healthiest half of bacteria, eliminate the other half
            Array.Sort(colony.bacteria); // sort from smallest health (best) to highest health (worst)
            for (int left = 0; left < S / 2; ++left) // left points to a bacterium that will reproduce
            {
              int right = left + S / 2; // right points to a bad bacterium in the rigt side of array that will die
              colony.bacteria[left].position.CopyTo(colony.bacteria[right].position, 0);
              colony.bacteria[right].cost = colony.bacteria[left].cost;
              colony.bacteria[right].prevCost = colony.bacteria[left].prevCost;
              colony.bacteria[right].health = colony.bacteria[left].health;
            }
 
          } // k, reproduction loop

          // eliminate-disperse
          for (int i = 0; i < S; ++i)
          {
            double prob = random.NextDouble();
            if (prob < Ped) // disperse this bacterium to a random position
            {
              for (int p = 0; p < dim; ++p)
              {
                double x = (maxValue - minValue) * random.NextDouble() + minValue;
                colony.bacteria[i].position[p] = x;
              }
              // update costs
              double cost = Cost(colony.bacteria[i].position); // compute
              colony.bacteria[i].cost = cost;
              colony.bacteria[i].prevCost = cost;
              colony.bacteria[i].health = 0.0;

              // new best by pure luck?
              if (colony.bacteria[i].cost < bestCost)
              {
                Console.WriteLine("New best solution found by bacteria " + i.ToString().PadLeft(2) + " at time = " + t);
                bestCost = colony.bacteria[i].cost;
                colony.bacteria[i].position.CopyTo(bestPosition, 0);
              }
            }
          }

        } // l, elimination-dispersal loop, end processing

        Console.WriteLine("\n\nAll BFO processing complete");
        Console.WriteLine("\nBest cost (minimum function value) found = " + bestCost.ToString("F4"));
        Console.Write("Best position/solution = ");
        ShowVector(bestPosition);


        Console.WriteLine("\nEnd BFO demo\n");
        Console.ReadLine();
      }
      catch (Exception ex)
      {
        Console.WriteLine("Fatal: " + ex.Message);
        //Console.ReadLine();
      }
    } // Main

    static void ShowVector(double[] vector) { Console.Write("[ "); for (int v = 0; v < vector.Length; ++v) { Console.Write(vector[v].ToString("F4") + " "); } Console.WriteLine("]"); }

    static double Cost(double[] position) // the Cost function we are trying to minimize
    {
      //  Rastrigin function. f(x,y) = (x^2 - 10*cos(2*PI*x)) + (y^2 - 10*cos(2*PI*y)) + 20 
      double result = 0.0;
      for (int i = 0; i < position.Length; ++i)
      {
        double xi = position[i];
        result += (xi * xi) - (10 * Math.Cos(2 * Math.PI * xi)) + 10;
      }
      return result;
    }

  } // class Program

  public class Colony // collection of Bacterium
  {
    public Bacterium[] bacteria;

    public Colony(int S, int dim, double minValue, double maxValue)
    {
      this.bacteria = new Bacterium[S];
      for (int i = 0; i < S; ++i)
        bacteria[i] = new Bacterium(dim, minValue, maxValue); // sets position and health but not cost
    }

    public override string ToString()
    {
      string s = "";
      for (int i = 0; i < this.bacteria.Length; ++i)
        s += "[" + i + "] : " + bacteria[i].ToString() + Environment.NewLine;
      return s;
    }

    // ========================================================================================================================================

    public class Bacterium : IComparable<Bacterium>
    {
      public double[] position;
      public double cost; // value we are trying to minimize
      public double prevCost;
      //public double swarmCost; // cost from intra-baceria proximity
      //public double prevSwarmCost;
      public double health; // accumulated measure per swim
      
      static Random random = new Random(0);

      public Bacterium(int dim, double minValue, double maxValue)
      {
        // random position bacterium
        this.position = new double[dim];
        for (int p = 0; p < dim; ++p)
        {
          double x = (maxValue - minValue) * random.NextDouble() + minValue;
          this.position[p] = x;
        }
        // costs are due to environment and must be computed extermally
        this.health = 0.0;
      }

      public override string ToString()
      {
        string s = "[ ";
        for (int p = 0; p < this.position.Length; ++p)
          s += position[p].ToString("F2") + " ";
        s += "] ";

        s += "cost = " + this.cost.ToString("F2") + " prevCost = " + this.prevCost.ToString("F2");
        s += " health = " + this.health.ToString("F2");
        
        return s;
      }

      public int CompareTo(Bacterium other)
      {
        if (this.health < other.health)
          return -1;
        else if (this.health > other.health)
          return 1;
        else
          return 0;
      }

    } // class Bacterium

    // ========================================================================================================================================

  } // class Colony

} // ns
