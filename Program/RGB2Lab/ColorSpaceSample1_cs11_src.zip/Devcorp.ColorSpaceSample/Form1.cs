using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using Devcorp.Controls.Design;

namespace Devcorp.ColorSpaceSample
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.GroupBox rgbGroup;
		private System.Windows.Forms.Label redLabel;
		private System.Windows.Forms.NumericUpDown redUD;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.NumericUpDown greenUD;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.NumericUpDown blueUD;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.NumericUpDown yUD;
		private System.Windows.Forms.NumericUpDown uUD;
		private System.Windows.Forms.NumericUpDown vUD;
		private System.Windows.Forms.NumericUpDown satUD;
		private System.Windows.Forms.NumericUpDown hueUD;
		private System.Windows.Forms.NumericUpDown lumUD;
		private System.Windows.Forms.GroupBox hslGroup;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.GroupBox hsbGroup;
		private System.Windows.Forms.GroupBox cmykGroup;
		private System.Windows.Forms.GroupBox yuvGroup;
		private System.Windows.Forms.NumericUpDown hUD;
		private System.Windows.Forms.NumericUpDown sUD;
		private System.Windows.Forms.NumericUpDown bUD;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.NumericUpDown yellowUD;
		private System.Windows.Forms.NumericUpDown blackUD;
		private System.Windows.Forms.NumericUpDown magentaUD;
		private System.Windows.Forms.NumericUpDown cyanUD;
		private System.Windows.Forms.TextBox hexBox;
		private System.Windows.Forms.Label label16;
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.Panel preview;
		private bool updating = false;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.redUD = new System.Windows.Forms.NumericUpDown();
			this.rgbGroup = new System.Windows.Forms.GroupBox();
			this.label1 = new System.Windows.Forms.Label();
			this.greenUD = new System.Windows.Forms.NumericUpDown();
			this.redLabel = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.blueUD = new System.Windows.Forms.NumericUpDown();
			this.hslGroup = new System.Windows.Forms.GroupBox();
			this.label3 = new System.Windows.Forms.Label();
			this.satUD = new System.Windows.Forms.NumericUpDown();
			this.label4 = new System.Windows.Forms.Label();
			this.hueUD = new System.Windows.Forms.NumericUpDown();
			this.label5 = new System.Windows.Forms.Label();
			this.lumUD = new System.Windows.Forms.NumericUpDown();
			this.cmykGroup = new System.Windows.Forms.GroupBox();
			this.label15 = new System.Windows.Forms.Label();
			this.blackUD = new System.Windows.Forms.NumericUpDown();
			this.label9 = new System.Windows.Forms.Label();
			this.magentaUD = new System.Windows.Forms.NumericUpDown();
			this.label10 = new System.Windows.Forms.Label();
			this.cyanUD = new System.Windows.Forms.NumericUpDown();
			this.label11 = new System.Windows.Forms.Label();
			this.yellowUD = new System.Windows.Forms.NumericUpDown();
			this.yuvGroup = new System.Windows.Forms.GroupBox();
			this.label12 = new System.Windows.Forms.Label();
			this.uUD = new System.Windows.Forms.NumericUpDown();
			this.label13 = new System.Windows.Forms.Label();
			this.yUD = new System.Windows.Forms.NumericUpDown();
			this.label14 = new System.Windows.Forms.Label();
			this.vUD = new System.Windows.Forms.NumericUpDown();
			this.hsbGroup = new System.Windows.Forms.GroupBox();
			this.label6 = new System.Windows.Forms.Label();
			this.sUD = new System.Windows.Forms.NumericUpDown();
			this.label7 = new System.Windows.Forms.Label();
			this.hUD = new System.Windows.Forms.NumericUpDown();
			this.label8 = new System.Windows.Forms.Label();
			this.bUD = new System.Windows.Forms.NumericUpDown();
			this.preview = new System.Windows.Forms.Panel();
			this.hexBox = new System.Windows.Forms.TextBox();
			this.label16 = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.redUD)).BeginInit();
			this.rgbGroup.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.greenUD)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.blueUD)).BeginInit();
			this.hslGroup.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.satUD)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.hueUD)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.lumUD)).BeginInit();
			this.cmykGroup.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.blackUD)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.magentaUD)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.cyanUD)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.yellowUD)).BeginInit();
			this.yuvGroup.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.uUD)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.yUD)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.vUD)).BeginInit();
			this.hsbGroup.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.sUD)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.hUD)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.bUD)).BeginInit();
			this.SuspendLayout();
			// 
			// redUD
			// 
			this.redUD.Location = new System.Drawing.Point(56, 16);
			this.redUD.Maximum = new System.Decimal(new int[] {
																  255,
																  0,
																  0,
																  0});
			this.redUD.Name = "redUD";
			this.redUD.Size = new System.Drawing.Size(64, 20);
			this.redUD.TabIndex = 1;
			this.redUD.Value = new System.Decimal(new int[] {
																255,
																0,
																0,
																0});
			this.redUD.ValueChanged += new System.EventHandler(this.RGBValueChanged);
			// 
			// rgbGroup
			// 
			this.rgbGroup.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(200)), ((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.rgbGroup.Controls.Add(this.label1);
			this.rgbGroup.Controls.Add(this.greenUD);
			this.rgbGroup.Controls.Add(this.redLabel);
			this.rgbGroup.Controls.Add(this.redUD);
			this.rgbGroup.Controls.Add(this.label2);
			this.rgbGroup.Controls.Add(this.blueUD);
			this.rgbGroup.Location = new System.Drawing.Point(16, 112);
			this.rgbGroup.Name = "rgbGroup";
			this.rgbGroup.Size = new System.Drawing.Size(128, 96);
			this.rgbGroup.TabIndex = 0;
			this.rgbGroup.TabStop = false;
			this.rgbGroup.Text = "RGB";
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.Location = new System.Drawing.Point(8, 40);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(48, 20);
			this.label1.TabIndex = 2;
			this.label1.Text = "Green";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// greenUD
			// 
			this.greenUD.Location = new System.Drawing.Point(56, 40);
			this.greenUD.Maximum = new System.Decimal(new int[] {
																	255,
																	0,
																	0,
																	0});
			this.greenUD.Name = "greenUD";
			this.greenUD.Size = new System.Drawing.Size(64, 20);
			this.greenUD.TabIndex = 3;
			this.greenUD.ValueChanged += new System.EventHandler(this.RGBValueChanged);
			// 
			// redLabel
			// 
			this.redLabel.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.redLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.redLabel.Location = new System.Drawing.Point(8, 16);
			this.redLabel.Name = "redLabel";
			this.redLabel.Size = new System.Drawing.Size(48, 20);
			this.redLabel.TabIndex = 0;
			this.redLabel.Text = "Red";
			this.redLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label2.Location = new System.Drawing.Point(8, 64);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(48, 20);
			this.label2.TabIndex = 4;
			this.label2.Text = "Blue";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// blueUD
			// 
			this.blueUD.Location = new System.Drawing.Point(56, 64);
			this.blueUD.Maximum = new System.Decimal(new int[] {
																   255,
																   0,
																   0,
																   0});
			this.blueUD.Name = "blueUD";
			this.blueUD.Size = new System.Drawing.Size(64, 20);
			this.blueUD.TabIndex = 5;
			this.blueUD.ValueChanged += new System.EventHandler(this.RGBValueChanged);
			// 
			// hslGroup
			// 
			this.hslGroup.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(200)), ((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.hslGroup.Controls.Add(this.label3);
			this.hslGroup.Controls.Add(this.satUD);
			this.hslGroup.Controls.Add(this.label4);
			this.hslGroup.Controls.Add(this.hueUD);
			this.hslGroup.Controls.Add(this.label5);
			this.hslGroup.Controls.Add(this.lumUD);
			this.hslGroup.Location = new System.Drawing.Point(160, 8);
			this.hslGroup.Name = "hslGroup";
			this.hslGroup.Size = new System.Drawing.Size(144, 96);
			this.hslGroup.TabIndex = 1;
			this.hslGroup.TabStop = false;
			this.hslGroup.Text = "HSL";
			// 
			// label3
			// 
			this.label3.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label3.Location = new System.Drawing.Point(8, 40);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(64, 20);
			this.label3.TabIndex = 2;
			this.label3.Text = "Saturation";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// satUD
			// 
			this.satUD.Location = new System.Drawing.Point(72, 40);
			this.satUD.Name = "satUD";
			this.satUD.Size = new System.Drawing.Size(64, 20);
			this.satUD.TabIndex = 3;
			this.satUD.ValueChanged += new System.EventHandler(this.HSLValueChanged);
			// 
			// label4
			// 
			this.label4.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label4.Location = new System.Drawing.Point(8, 16);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(56, 20);
			this.label4.TabIndex = 0;
			this.label4.Text = "Hue";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// hueUD
			// 
			this.hueUD.Location = new System.Drawing.Point(72, 16);
			this.hueUD.Maximum = new System.Decimal(new int[] {
																  360,
																  0,
																  0,
																  0});
			this.hueUD.Name = "hueUD";
			this.hueUD.Size = new System.Drawing.Size(64, 20);
			this.hueUD.TabIndex = 1;
			this.hueUD.ValueChanged += new System.EventHandler(this.HSLValueChanged);
			// 
			// label5
			// 
			this.label5.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label5.Location = new System.Drawing.Point(8, 64);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(64, 20);
			this.label5.TabIndex = 4;
			this.label5.Text = "Luminance";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lumUD
			// 
			this.lumUD.Location = new System.Drawing.Point(72, 64);
			this.lumUD.Name = "lumUD";
			this.lumUD.Size = new System.Drawing.Size(64, 20);
			this.lumUD.TabIndex = 5;
			this.lumUD.ValueChanged += new System.EventHandler(this.HSLValueChanged);
			// 
			// cmykGroup
			// 
			this.cmykGroup.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(200)), ((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.cmykGroup.Controls.Add(this.label15);
			this.cmykGroup.Controls.Add(this.blackUD);
			this.cmykGroup.Controls.Add(this.label9);
			this.cmykGroup.Controls.Add(this.magentaUD);
			this.cmykGroup.Controls.Add(this.label10);
			this.cmykGroup.Controls.Add(this.cyanUD);
			this.cmykGroup.Controls.Add(this.label11);
			this.cmykGroup.Controls.Add(this.yellowUD);
			this.cmykGroup.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.cmykGroup.Location = new System.Drawing.Point(320, 176);
			this.cmykGroup.Name = "cmykGroup";
			this.cmykGroup.Size = new System.Drawing.Size(144, 120);
			this.cmykGroup.TabIndex = 3;
			this.cmykGroup.TabStop = false;
			this.cmykGroup.Text = "CMYK";
			// 
			// label15
			// 
			this.label15.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label15.Location = new System.Drawing.Point(8, 88);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(64, 20);
			this.label15.TabIndex = 6;
			this.label15.Text = "Black";
			this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// blackUD
			// 
			this.blackUD.Location = new System.Drawing.Point(72, 88);
			this.blackUD.Name = "blackUD";
			this.blackUD.Size = new System.Drawing.Size(64, 20);
			this.blackUD.TabIndex = 7;
			this.blackUD.ValueChanged += new System.EventHandler(this.CMYKValueChanged);
			// 
			// label9
			// 
			this.label9.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label9.Location = new System.Drawing.Point(8, 40);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(64, 20);
			this.label9.TabIndex = 2;
			this.label9.Text = "Magenta";
			this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// magentaUD
			// 
			this.magentaUD.Location = new System.Drawing.Point(72, 40);
			this.magentaUD.Name = "magentaUD";
			this.magentaUD.Size = new System.Drawing.Size(64, 20);
			this.magentaUD.TabIndex = 3;
			this.magentaUD.ValueChanged += new System.EventHandler(this.CMYKValueChanged);
			// 
			// label10
			// 
			this.label10.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label10.Location = new System.Drawing.Point(8, 16);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(64, 20);
			this.label10.TabIndex = 0;
			this.label10.Text = "Cyan";
			this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// cyanUD
			// 
			this.cyanUD.Location = new System.Drawing.Point(72, 16);
			this.cyanUD.Name = "cyanUD";
			this.cyanUD.Size = new System.Drawing.Size(64, 20);
			this.cyanUD.TabIndex = 0;
			this.cyanUD.ValueChanged += new System.EventHandler(this.CMYKValueChanged);
			// 
			// label11
			// 
			this.label11.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label11.Location = new System.Drawing.Point(8, 64);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(64, 20);
			this.label11.TabIndex = 4;
			this.label11.Text = "Yellow";
			this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// yellowUD
			// 
			this.yellowUD.Location = new System.Drawing.Point(72, 64);
			this.yellowUD.Name = "yellowUD";
			this.yellowUD.Size = new System.Drawing.Size(64, 20);
			this.yellowUD.TabIndex = 5;
			this.yellowUD.ValueChanged += new System.EventHandler(this.CMYKValueChanged);
			// 
			// yuvGroup
			// 
			this.yuvGroup.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(200)), ((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.yuvGroup.Controls.Add(this.label12);
			this.yuvGroup.Controls.Add(this.uUD);
			this.yuvGroup.Controls.Add(this.label13);
			this.yuvGroup.Controls.Add(this.yUD);
			this.yuvGroup.Controls.Add(this.label14);
			this.yuvGroup.Controls.Add(this.vUD);
			this.yuvGroup.Location = new System.Drawing.Point(168, 248);
			this.yuvGroup.Name = "yuvGroup";
			this.yuvGroup.Size = new System.Drawing.Size(128, 96);
			this.yuvGroup.TabIndex = 4;
			this.yuvGroup.TabStop = false;
			this.yuvGroup.Text = "YUV";
			// 
			// label12
			// 
			this.label12.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label12.Location = new System.Drawing.Point(8, 40);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(48, 20);
			this.label12.TabIndex = 2;
			this.label12.Text = "U";
			this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// uUD
			// 
			this.uUD.Location = new System.Drawing.Point(56, 40);
			this.uUD.Maximum = new System.Decimal(new int[] {
																87,
																0,
																0,
																0});
			this.uUD.Name = "uUD";
			this.uUD.Size = new System.Drawing.Size(64, 20);
			this.uUD.TabIndex = 3;
			this.uUD.ValueChanged += new System.EventHandler(this.YUVValueChanged);
			// 
			// label13
			// 
			this.label13.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label13.Location = new System.Drawing.Point(8, 16);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(48, 20);
			this.label13.TabIndex = 0;
			this.label13.Text = "Y";
			this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// yUD
			// 
			this.yUD.Location = new System.Drawing.Point(56, 16);
			this.yUD.Name = "yUD";
			this.yUD.Size = new System.Drawing.Size(64, 20);
			this.yUD.TabIndex = 1;
			this.yUD.ValueChanged += new System.EventHandler(this.YUVValueChanged);
			// 
			// label14
			// 
			this.label14.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label14.Location = new System.Drawing.Point(8, 64);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(48, 20);
			this.label14.TabIndex = 4;
			this.label14.Text = "V";
			this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// vUD
			// 
			this.vUD.Location = new System.Drawing.Point(56, 64);
			this.vUD.Maximum = new System.Decimal(new int[] {
																123,
																0,
																0,
																0});
			this.vUD.Name = "vUD";
			this.vUD.Size = new System.Drawing.Size(64, 20);
			this.vUD.TabIndex = 5;
			this.vUD.ValueChanged += new System.EventHandler(this.YUVValueChanged);
			// 
			// hsbGroup
			// 
			this.hsbGroup.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(200)), ((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.hsbGroup.Controls.Add(this.label6);
			this.hsbGroup.Controls.Add(this.sUD);
			this.hsbGroup.Controls.Add(this.label7);
			this.hsbGroup.Controls.Add(this.hUD);
			this.hsbGroup.Controls.Add(this.label8);
			this.hsbGroup.Controls.Add(this.bUD);
			this.hsbGroup.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.hsbGroup.Location = new System.Drawing.Point(320, 64);
			this.hsbGroup.Name = "hsbGroup";
			this.hsbGroup.Size = new System.Drawing.Size(144, 96);
			this.hsbGroup.TabIndex = 2;
			this.hsbGroup.TabStop = false;
			this.hsbGroup.Text = "HSB";
			// 
			// label6
			// 
			this.label6.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label6.Location = new System.Drawing.Point(8, 40);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(64, 20);
			this.label6.TabIndex = 2;
			this.label6.Text = "Saturation";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// sUD
			// 
			this.sUD.Location = new System.Drawing.Point(72, 40);
			this.sUD.Name = "sUD";
			this.sUD.Size = new System.Drawing.Size(64, 20);
			this.sUD.TabIndex = 3;
			this.sUD.ValueChanged += new System.EventHandler(this.HSBValueChanged);
			// 
			// label7
			// 
			this.label7.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label7.Location = new System.Drawing.Point(8, 16);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(56, 20);
			this.label7.TabIndex = 0;
			this.label7.Text = "Hue";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// hUD
			// 
			this.hUD.Location = new System.Drawing.Point(72, 16);
			this.hUD.Maximum = new System.Decimal(new int[] {
																360,
																0,
																0,
																0});
			this.hUD.Name = "hUD";
			this.hUD.Size = new System.Drawing.Size(64, 20);
			this.hUD.TabIndex = 1;
			this.hUD.ValueChanged += new System.EventHandler(this.HSBValueChanged);
			// 
			// label8
			// 
			this.label8.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label8.Location = new System.Drawing.Point(8, 64);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(64, 20);
			this.label8.TabIndex = 4;
			this.label8.Text = "Brightness";
			this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// bUD
			// 
			this.bUD.Location = new System.Drawing.Point(72, 64);
			this.bUD.Name = "bUD";
			this.bUD.Size = new System.Drawing.Size(64, 20);
			this.bUD.TabIndex = 5;
			this.bUD.ValueChanged += new System.EventHandler(this.HSBValueChanged);
			// 
			// preview
			// 
			this.preview.BackColor = System.Drawing.Color.Red;
			this.preview.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.preview.Location = new System.Drawing.Point(184, 136);
			this.preview.Name = "preview";
			this.preview.Size = new System.Drawing.Size(88, 88);
			this.preview.TabIndex = 5;
			// 
			// hexBox
			// 
			this.hexBox.Location = new System.Drawing.Point(72, 216);
			this.hexBox.Name = "hexBox";
			this.hexBox.Size = new System.Drawing.Size(64, 20);
			this.hexBox.TabIndex = 6;
			this.hexBox.Text = "#FF0000";
			// 
			// label16
			// 
			this.label16.BackColor = System.Drawing.Color.White;
			this.label16.Location = new System.Drawing.Point(24, 216);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(48, 20);
			this.label16.TabIndex = 6;
			this.label16.Text = "Hexa";
			this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
			this.ClientSize = new System.Drawing.Size(480, 362);
			this.Controls.Add(this.hexBox);
			this.Controls.Add(this.preview);
			this.Controls.Add(this.hsbGroup);
			this.Controls.Add(this.yuvGroup);
			this.Controls.Add(this.cmykGroup);
			this.Controls.Add(this.hslGroup);
			this.Controls.Add(this.rgbGroup);
			this.Controls.Add(this.label16);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Name = "Form1";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Color space sample";
			this.Load += new System.EventHandler(this.Form1_Load);
			((System.ComponentModel.ISupportInitialize)(this.redUD)).EndInit();
			this.rgbGroup.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.greenUD)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.blueUD)).EndInit();
			this.hslGroup.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.satUD)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.hueUD)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.lumUD)).EndInit();
			this.cmykGroup.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.blackUD)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.magentaUD)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.cyanUD)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.yellowUD)).EndInit();
			this.yuvGroup.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.uUD)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.yUD)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.vUD)).EndInit();
			this.hsbGroup.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.sUD)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.hUD)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.bUD)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.EnableVisualStyles();
			Application.DoEvents();
			Application.Run(new Form1());
		}

		#region Handlers
		private void RGBValueChanged(object sender, System.EventArgs e)
		{
			if(!this.updating)
			{
				this.preview.BackColor = Color.FromArgb((int)redUD.Value, (int)greenUD.Value, (int)blueUD.Value);
				this.hexBox.Text = ColorSpaceHelper.RGBToHex((int)redUD.Value, (int)greenUD.Value, (int)blueUD.Value);

				this.updating = true;
				UpdateHSL(ColorSpaceHelper.RGBtoHSL((int)redUD.Value, (int)greenUD.Value, (int)blueUD.Value));
				UpdateHSB(ColorSpaceHelper.RGBtoHSB((int)redUD.Value, (int)greenUD.Value, (int)blueUD.Value));
				UpdateCMYK(ColorSpaceHelper.RGBtoCMYK((int)redUD.Value, (int)greenUD.Value, (int)blueUD.Value));
				UpdateYUV(ColorSpaceHelper.RGBtoYUV((int)redUD.Value, (int)greenUD.Value, (int)blueUD.Value));
				this.updating = false;
			}
		}

		private void HSLValueChanged(object sender, System.EventArgs e)
		{
			if(!this.updating)
			{
				this.updating = true;
				UpdateRGB(ColorSpaceHelper.HSLtoRGB((double)this.hueUD.Value, (double)this.satUD.Value/100.0, (double)this.lumUD.Value/100.0));
				UpdateHSB(ColorSpaceHelper.RGBtoHSB((int)redUD.Value, (int)greenUD.Value, (int)blueUD.Value));
				UpdateCMYK(ColorSpaceHelper.RGBtoCMYK((int)redUD.Value, (int)greenUD.Value, (int)blueUD.Value));
				UpdateYUV(ColorSpaceHelper.RGBtoYUV((int)redUD.Value, (int)greenUD.Value, (int)blueUD.Value));
				this.updating = false;
			}
		}

		private void HSBValueChanged(object sender, System.EventArgs e)
		{
			if(!this.updating)
			{
				this.updating = true;
				UpdateRGB(ColorSpaceHelper.HSBtoRGB((double)this.hUD.Value, (double)this.sUD.Value/100.0, (double)this.bUD.Value/100.0));
				UpdateHSL(ColorSpaceHelper.RGBtoHSL((int)redUD.Value, (int)greenUD.Value, (int)blueUD.Value));
				UpdateCMYK(ColorSpaceHelper.RGBtoCMYK((int)redUD.Value, (int)greenUD.Value, (int)blueUD.Value));
				UpdateYUV(ColorSpaceHelper.RGBtoYUV((int)redUD.Value, (int)greenUD.Value, (int)blueUD.Value));
				this.updating = false;
			}
		}

		private void CMYKValueChanged(object sender, System.EventArgs e)
		{
			if(!this.updating)
			{
				this.updating = true;
				UpdateRGB(ColorSpaceHelper.CMYKtoRGB((double)this.cyanUD.Value/100.0, (double)this.magentaUD.Value/100.0, (double)this.yellowUD.Value/100.0, (double)this.blackUD.Value/100.0));
				UpdateHSL(ColorSpaceHelper.RGBtoHSL((int)redUD.Value, (int)greenUD.Value, (int)blueUD.Value));
				UpdateHSB(ColorSpaceHelper.RGBtoHSB((int)redUD.Value, (int)greenUD.Value, (int)blueUD.Value));
				UpdateYUV(ColorSpaceHelper.RGBtoYUV((int)redUD.Value, (int)greenUD.Value, (int)blueUD.Value));
				this.updating = false;
			}
		}

		private void YUVValueChanged(object sender, System.EventArgs e)
		{
			if(!this.updating)
			{
				this.updating = true;
				UpdateRGB(ColorSpaceHelper.YUVtoRGB((double)this.yUD.Value/100.0, (-0.436 + ((double)this.uUD.Value/100.0)), (-0.615 + ((double)this.vUD.Value/100.0))));
				UpdateCMYK(ColorSpaceHelper.RGBtoCMYK((int)redUD.Value, (int)greenUD.Value, (int)blueUD.Value));
				UpdateHSL(ColorSpaceHelper.RGBtoHSL((int)redUD.Value, (int)greenUD.Value, (int)blueUD.Value));
				UpdateHSB(ColorSpaceHelper.RGBtoHSB((int)redUD.Value, (int)greenUD.Value, (int)blueUD.Value));
				this.updating = false;
			}
		}

		#endregion

		#region Updates
		private void UpdateRGB(RGB rgb)
		{
			if(Convert.ToInt32(redUD.Value) != rgb.Red) this.redUD.Value = rgb.Red;
			if(Convert.ToInt32(greenUD.Value) != rgb.Green) this.greenUD.Value = rgb.Green;
			if(Convert.ToInt32(blueUD.Value) != rgb.Blue) this.blueUD.Value = rgb.Blue;

			this.preview.BackColor = Color.FromArgb(rgb.Red, rgb.Green, rgb.Blue);
			this.hexBox.Text = ColorSpaceHelper.RGBToHex(rgb.Red, rgb.Green, rgb.Blue);
		}

		private void UpdateHSL(HSL hsl)
		{
			if(Convert.ToInt32(hsl.Hue) != (int)this.hueUD.Value) this.hueUD.Value = Convert.ToInt32(hsl.Hue);
			if(Convert.ToInt32(hsl.Saturation*100) != (int)this.satUD.Value) this.satUD.Value = Convert.ToInt32(hsl.Saturation*100);
			if(Convert.ToInt32(hsl.Luminance*100) != (int)this.lumUD.Value) this.lumUD.Value = Convert.ToInt32(hsl.Luminance*100);
		}

		private void UpdateHSB(HSB hsb)
		{
			if(Convert.ToInt32(hsb.Hue) != (int)this.hUD.Value)	this.hUD.Value = Convert.ToInt32(hsb.Hue);
			if(Convert.ToInt32(hsb.Saturation*100) != (int)this.sUD.Value) this.sUD.Value = Convert.ToInt32(hsb.Saturation*100);
			if(Convert.ToInt32(hsb.Brightness*100) != (int)this.bUD.Value) this.bUD.Value = Convert.ToInt32(hsb.Brightness*100);
		}

		private void UpdateCMYK(CMYK cmyk)
		{
			if(Convert.ToInt32(cmyk.Cyan*100) != (int)this.cyanUD.Value) this.cyanUD.Value = Convert.ToInt32(cmyk.Cyan*100);
			if(Convert.ToInt32(cmyk.Magenta*100) != (int)this.magentaUD.Value) this.magentaUD.Value = Convert.ToInt32(cmyk.Magenta*100);
			if(Convert.ToInt32(cmyk.Yellow*100) != (int)this.yellowUD.Value) this.yellowUD.Value = Convert.ToInt32(cmyk.Yellow*100);
			if(Convert.ToInt32(cmyk.Black*100) != (int)this.blackUD.Value) this.blackUD.Value = Convert.ToInt32(cmyk.Black*100);
		}

		private void UpdateYUV(YUV yuv)
		{
			if(Convert.ToInt32(yuv.Y*100) != (int)this.yUD.Value) this.yUD.Value = Convert.ToInt32(yuv.Y*100);
			if(Convert.ToInt32((yuv.U+0.436)*100) != (int)this.uUD.Value) this.uUD.Value = Convert.ToInt32((yuv.U+0.436)*100);
			if(Convert.ToInt32((yuv.V+0.615)*100) != (int)this.vUD.Value) this.vUD.Value = Convert.ToInt32((yuv.V+0.615)*100);
		}

		#endregion

		private void Form1_Load(object sender, System.EventArgs e)
		{
			this.updating = true;
			UpdateHSL(ColorSpaceHelper.RGBtoHSL((int)redUD.Value, (int)greenUD.Value, (int)blueUD.Value));
			UpdateHSB(ColorSpaceHelper.RGBtoHSB((int)redUD.Value, (int)greenUD.Value, (int)blueUD.Value));
			UpdateCMYK(ColorSpaceHelper.RGBtoCMYK((int)redUD.Value, (int)greenUD.Value, (int)blueUD.Value));
			UpdateYUV(ColorSpaceHelper.RGBtoYUV((int)redUD.Value, (int)greenUD.Value, (int)blueUD.Value));
			this.updating = false;
		}
	}
}
